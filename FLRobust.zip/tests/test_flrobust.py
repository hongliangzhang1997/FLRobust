import copy
import pathlib
import sys
import unittest
from types import SimpleNamespace

import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset


PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from flrobust import (  # noqa: E402
    FLRobustServer,
    clone_state_dict_to_cpu,
    coordinate_median,
    run_secondary_optimization,
    top_fraction_mask,
)


class TinyClassifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(4, 8),
            nn.ReLU(),
            nn.Linear(8, 3),
        )

    def forward(self, inputs):
        return self.network(inputs)


class FLRobustUtilityTests(unittest.TestCase):
    def test_top_fraction_uses_ceiling(self):
        vector = torch.tensor([1.0, -5.0, 3.0, 2.0, 0.0])
        mask = top_fraction_mask(vector, 0.3)
        self.assertEqual(mask.sum().item(), 2)
        self.assertTrue(mask[1].item())
        self.assertTrue(mask[2].item())

    def test_coordinate_median_averages_middle_values(self):
        values = torch.tensor([[1.0, 7.0], [3.0, 1.0], [5.0, 5.0], [9.0, 3.0]])
        median = coordinate_median(values)
        self.assertTrue(torch.allclose(median, torch.tensor([4.0, 4.0])))


class SecondaryOptimizationTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(4)
        self.reference_model = TinyClassifier()
        self.local_model = copy.deepcopy(self.reference_model)
        with torch.no_grad():
            next(self.local_model.parameters()).add_(0.2)
        inputs = torch.randn(12, 4)
        labels = torch.randint(0, 3, (12,))
        self.loader = DataLoader(TensorDataset(inputs, labels), batch_size=4)

    def _args(self, zeta, emax):
        return SimpleNamespace(
            device=torch.device("cpu"),
            flrobust_zeta=zeta,
            flrobust_emax=emax,
            flrobust_tau=0.5,
            flrobust_mu=1.0,
            flrobust_secondary_lr=0.1,
            flrobust_eps=1e-12,
        )

    def test_secondary_optimization_honors_maximum_iterations(self):
        before = [parameter.detach().clone() for parameter in self.local_model.parameters()]
        stats = run_secondary_optimization(
            self.local_model,
            copy.deepcopy(self.reference_model),
            clone_state_dict_to_cpu(self.reference_model),
            self.loader,
            self._args(zeta=1.1, emax=2),
        )
        self.assertTrue(stats["activated"])
        self.assertEqual(stats["steps"], 2)
        self.assertTrue(
            any(
                not torch.equal(old, new)
                for old, new in zip(before, self.local_model.parameters())
            )
        )

    def test_secondary_optimization_can_be_skipped(self):
        stats = run_secondary_optimization(
            self.local_model,
            copy.deepcopy(self.reference_model),
            None,
            self.loader,
            self._args(zeta=-1.0, emax=5),
        )
        self.assertFalse(stats["activated"])
        self.assertEqual(stats["steps"], 0)


class ServerAggregationTests(unittest.TestCase):
    def test_suspicious_sign_pattern_is_filtered_and_reputation_persists(self):
        updates = {
            0: torch.tensor([4.2, 3.1, 2.2, 0.2, 0.1, 0.0]),
            1: torch.tensor([3.9, 2.8, 1.9, 0.1, 0.0, 0.1]),
            2: torch.tensor([4.1, 3.2, 2.1, 0.0, 0.2, 0.1]),
            3: torch.tensor([3.8, 2.9, 1.8, 0.1, 0.1, 0.2]),
            4: torch.tensor([-8.0, -7.0, -6.0, 0.0, 0.0, 0.0]),
        }
        server = FLRobustServer(kappa=0.5, threshold=0.6, decay=0.6)

        aggregated, diagnostics = server.aggregate(updates)
        self.assertEqual(aggregated.shape, updates[0].shape)
        self.assertTrue(torch.isfinite(aggregated).all().item())
        self.assertNotIn(4, diagnostics["selected_client_ids"])
        self.assertLess(diagnostics["reputations"][4], diagnostics["reputations"][0])

        _, second_diagnostics = server.aggregate(updates)
        self.assertLess(
            second_diagnostics["reputations"][4],
            second_diagnostics["reputations"][0],
        )


if __name__ == "__main__":
    unittest.main()
