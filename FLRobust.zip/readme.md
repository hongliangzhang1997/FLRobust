# FLRobust Implementation

This project integrates **FLRobust** into the public AlignIns federated-learning
codebase. The implementation follows the supplied FLRobust manuscript and keeps
the original aggregation baselines available for comparison.

## Implemented FLRobust pipeline

FLRobust is selected with `--aggr flrobust` and executes the following stages:

1. **Adaptive secondary optimization (client side).** After conventional local
   cross-entropy training, the client compares its updated model with the previous
   global model. If their cosine similarity is below `zeta`, the client optimizes a
   contrastive term and a global-to-local distillation term until the similarity
   reaches `zeta` or `E_max` mini-batch steps have been performed.
2. **Update sparsification (server side).** For every update, the server intersects
   a top-magnitude mask with a top coordinate-wise median-deviation mask and keeps
   only the resulting critical coordinates for inspection.
3. **Update inspection (server side).** The server computes the
   magnitude-weighted sign-alignment (MWSA) score, converts its median offset to a
   Z-score, and retains clients whose normalized offset is below `lambda`.
4. **Dynamic reputation aggregation (server side).** Historical benign/malicious
   counters are updated with decay factor `epsilon`; retained updates are aggregated
   using their reputations as normalized weights.

The original repository stores updates as `w_k - W`, whereas the manuscript writes
`Delta_k = W - w_k`. The implementation keeps the repository convention so that the
existing global update remains correct. FLRobust's absolute-value masks and sign
alignment are invariant to this common sign reversal.

## Code map

| Component | File |
| --- | --- |
| Secondary contrastive/distillation optimization | `src/flrobust.py` |
| Client integration and per-client local-model history | `src/agent.py` |
| Sparsification, MWSA, reputation state, and weighted aggregation | `src/flrobust.py` |
| Aggregation-rule dispatch and diagnostics | `src/aggregation.py` |
| FLRobust command-line arguments | `src/federated.py` |
| ResNet18 and SVHN support | `src/models.py`, `src/utils.py` |
| Unit tests | `tests/test_flrobust.py` |

## Environment

The original Conda environment is recorded in `env.yaml`.

```bash
conda env create -f env.yaml
conda activate fl
```

## FLRobust example

Run commands from `src/`, as expected by the original logging code:

```bash
cd src
python federated.py \
  --aggr flrobust \
  --data cifar10 \
  --model resnet18 \
  --num_agents 100 \
  --agent_frac 0.3 \
  --num_corrupt 40 \
  --non_iid \
  --beta 0.5 \
  --attack neurotoxin \
  --poison_frac 0.5 \
  --bs 50 \
  --local_ep 2 \
  --client_lr 0.1 \
  --server_lr 1.0 \
  --sparsity 0.3 \
  --flrobust_zeta 0.0 \
  --flrobust_tau 0.5 \
  --flrobust_mu 1.0 \
  --flrobust_secondary_lr 0.5 \
  --flrobust_emax 5 \
  --flrobust_lambda 0.6 \
  --flrobust_decay 0.6
```

The manuscript allows malicious clients to deviate from the prescribed local
procedure. Accordingly, simulated malicious clients bypass secondary optimization
by default. Add `--flrobust_apply_so_to_malicious` only for an ablation in which all
clients are forced to follow the client-side procedure.

## FLRobust arguments

| Argument | Meaning | Default |
| --- | --- | ---: |
| `--sparsity` | Critical-coordinate proportion `kappa` | `0.3` |
| `--flrobust_zeta` | Secondary-optimization activation/stopping threshold | `0.0` |
| `--flrobust_tau` | Contrastive temperature | `0.5` |
| `--flrobust_mu` | Distillation-term weight | `1.0` |
| `--flrobust_secondary_lr` | Secondary learning rate | `0.5` |
| `--flrobust_emax` | Maximum secondary iterations | `5` |
| `--flrobust_lambda` | Normalized median-offset threshold | `0.6` |
| `--flrobust_decay` | Reputation decay factor | `0.6` |
| `--flrobust_eps` | Numerical safeguard | `1e-12` |

## Tests

After installing the environment, run from the project root:

```bash
python -m unittest discover -s tests -v
```

## Original AlignIns implementation

This project is derived from the official implementation of the CVPR 2025 Highlight
paper **"Detecting Backdoor Attacks in Federated Learning via Direction Alignment
Inspection"**. The original AlignIns aggregation rule remains in
`src/aggregation.py`.

```bibtex
@InProceedings{Xu_2025_CVPR_AlignIns,
    author    = {Xu, Jiahao and Zhang, Zikai and Hu, Rui},
    title     = {Detecting Backdoor Attacks in Federated Learning via Direction Alignment Inspection},
    booktitle = {Proceedings of the Computer Vision and Pattern Recognition Conference (CVPR)},
    month     = {June},
    year      = {2025},
    pages     = {20654--20664}
}
```

The original code also acknowledges the Lockdown project:
<https://github.com/git-disl/Lockdown>.
