"""Core client- and server-side components of FLRobust.

The implementation follows the method in ``feature(1).pdf``:

* adaptive local secondary optimization with contrastive and distillation losses;
* two-mask update sparsification followed by magnitude-weighted sign alignment;
* dynamic reputation-based aggregation across communication rounds.

The surrounding AlignIns code represents a client update as ``w_k - W`` while
the paper uses ``Delta_k = W - w_k``.  The global update below follows the
repository convention.  Absolute-value masks and sign-alignment decisions are
invariant to this common sign reversal.
"""

import copy
import math

import torch
import torch.nn.functional as F
from torch.nn.utils import parameters_to_vector


def clone_state_dict_to_cpu(model):
    """Return a detached CPU snapshot suitable for per-client history."""
    return {
        name: tensor.detach().cpu().clone()
        for name, tensor in model.state_dict().items()
    }


def _last_linear_layer(model):
    """Find the classifier used to expose its input feature representation."""
    linear_layers = [module for module in model.modules() if isinstance(module, torch.nn.Linear)]
    if not linear_layers:
        raise ValueError(
            "FLRobust secondary optimization requires a model with at least one "
            "torch.nn.Linear classifier layer."
        )
    return linear_layers[-1]


def forward_with_representation(model, inputs):
    """Return model logits and the feature vector entering the last linear layer.

    A short-lived pre-forward hook keeps the implementation architecture-agnostic
    for the ResNet9, VGG9, and torchvision ResNet18 models in this repository.
    """
    captured = []

    def capture_input(_module, layer_inputs):
        captured.append(layer_inputs[0])

    handle = _last_linear_layer(model).register_forward_pre_hook(capture_input)
    try:
        logits = model(inputs)
    finally:
        handle.remove()

    if not captured:
        raise RuntimeError("Unable to capture the model representation for FLRobust.")

    representation = captured[0]
    if representation.ndim > 2:
        representation = torch.flatten(representation, start_dim=1)
    return logits, representation


def model_cosine_similarity(model, reference_model, eps=1e-12):
    """Compute cosine similarity between the trainable parameter vectors."""
    current = parameters_to_vector(model.parameters())
    reference = parameters_to_vector(reference_model.parameters()).to(current.device)
    return F.cosine_similarity(current, reference, dim=0, eps=eps)


def run_secondary_optimization(
    model,
    reference_global_model,
    previous_local_state,
    train_loader,
    args,
):
    """Adaptively run FLRobust secondary optimization in place.

    One secondary iteration is one mini-batch gradient step.  Optimization stops
    once the model/global cosine similarity reaches ``zeta`` or ``E_max`` steps
    have been performed.
    """
    zeta = float(args.flrobust_zeta)
    max_iterations = int(args.flrobust_emax)
    tau = float(args.flrobust_tau)
    mu = float(args.flrobust_mu)
    secondary_lr = float(args.flrobust_secondary_lr)
    eps = float(args.flrobust_eps)

    if tau <= 0:
        raise ValueError("--flrobust_tau must be greater than zero.")
    if max_iterations < 0:
        raise ValueError("--flrobust_emax must be non-negative.")

    reference_global_model.eval()
    for parameter in reference_global_model.parameters():
        parameter.requires_grad_(False)

    initial_similarity = model_cosine_similarity(
        model, reference_global_model, eps=eps
    ).detach()
    stats = {
        "activated": False,
        "steps": 0,
        "initial_similarity": float(initial_similarity.cpu()),
        "final_similarity": float(initial_similarity.cpu()),
        "contrastive_loss": 0.0,
        "distillation_loss": 0.0,
        "secondary_loss": 0.0,
    }

    if max_iterations == 0 or initial_similarity.item() >= zeta:
        return stats

    previous_local_model = copy.deepcopy(reference_global_model)
    if previous_local_state is not None:
        previous_local_model.load_state_dict(previous_local_state)
    previous_local_model.eval()
    for parameter in previous_local_model.parameters():
        parameter.requires_grad_(False)

    optimizer = torch.optim.SGD(model.parameters(), lr=secondary_lr)
    data_iterator = iter(train_loader)
    stats["activated"] = True
    model.train()

    for _ in range(max_iterations):
        current_similarity = model_cosine_similarity(
            model, reference_global_model, eps=eps
        )
        if current_similarity.item() >= zeta:
            break

        try:
            inputs, _ = next(data_iterator)
        except StopIteration:
            data_iterator = iter(train_loader)
            try:
                inputs, _ = next(data_iterator)
            except StopIteration as exc:
                raise RuntimeError(
                    "The local data loader is empty; secondary optimization cannot run."
                ) from exc

        inputs = inputs.to(device=args.device, non_blocking=True)
        optimizer.zero_grad()

        current_logits, current_features = forward_with_representation(model, inputs)
        with torch.no_grad():
            global_logits, global_features = forward_with_representation(
                reference_global_model, inputs
            )
            _, previous_features = forward_with_representation(
                previous_local_model, inputs
            )

        positive_similarity = F.cosine_similarity(
            current_features, global_features, dim=1, eps=eps
        )
        negative_similarity = F.cosine_similarity(
            current_features, previous_features, dim=1, eps=eps
        )
        contrastive_logits = torch.stack(
            (positive_similarity / tau, negative_similarity / tau), dim=1
        )
        positive_labels = torch.zeros(
            contrastive_logits.size(0), dtype=torch.long, device=contrastive_logits.device
        )
        contrastive_loss = F.cross_entropy(contrastive_logits, positive_labels)

        distillation_loss = F.kl_div(
            F.log_softmax(current_logits, dim=1),
            F.softmax(global_logits, dim=1),
            reduction="batchmean",
        )
        secondary_loss = contrastive_loss + mu * distillation_loss
        secondary_loss.backward()
        optimizer.step()

        stats["steps"] += 1
        stats["contrastive_loss"] = float(contrastive_loss.detach().cpu())
        stats["distillation_loss"] = float(distillation_loss.detach().cpu())
        stats["secondary_loss"] = float(secondary_loss.detach().cpu())

    final_similarity = model_cosine_similarity(
        model, reference_global_model, eps=eps
    ).detach()
    stats["final_similarity"] = float(final_similarity.cpu())
    return stats


def top_fraction_mask(vector, fraction):
    """Implement Sparse(Y, kappa) using ceil(kappa * d) coordinates."""
    if vector.ndim != 1:
        raise ValueError("Sparse expects a one-dimensional update vector.")
    if not 0 < fraction <= 1:
        raise ValueError("The sparsification fraction must lie in (0, 1].")

    selected_count = min(vector.numel(), max(1, math.ceil(fraction * vector.numel())))
    if selected_count == vector.numel():
        return torch.ones_like(vector, dtype=torch.bool)

    indices = torch.topk(vector.abs(), selected_count, sorted=False).indices
    mask = torch.zeros_like(vector, dtype=torch.bool)
    mask[indices] = True
    return mask


def coordinate_median(values):
    """Compute the conventional median along the client dimension."""
    if values.ndim < 1 or values.size(0) == 0:
        raise ValueError("At least one client value is required.")

    count = values.size(0)
    upper_rank = count // 2 + 1
    upper = torch.kthvalue(values, upper_rank, dim=0).values
    if count % 2 == 1:
        return upper
    lower = torch.kthvalue(values, count // 2, dim=0).values
    return (lower + upper) / 2


class FLRobustServer:
    """Stateful sparsified inspection and dynamic reputation aggregation."""

    def __init__(self, kappa=0.3, threshold=0.6, decay=0.6, eps=1e-12):
        if not 0 < kappa <= 1:
            raise ValueError("kappa must lie in (0, 1].")
        if not 0 <= decay <= 1:
            raise ValueError("reputation decay must lie in [0, 1].")
        if eps <= 0:
            raise ValueError("eps must be positive.")

        self.kappa = float(kappa)
        self.threshold = float(threshold)
        self.decay = float(decay)
        self.eps = float(eps)
        self.benign_counts = {}
        self.malicious_counts = {}
        self.last_diagnostics = {}

    def _magnitude_weighted_sign_alignment(self, updates):
        absolute_updates = updates.abs()
        median_magnitude = coordinate_median(absolute_updates)
        plausible_sign = torch.sign(torch.sign(updates).sum(dim=0))

        scores = []
        retained_coordinates = []
        for update, update_magnitude in zip(updates, absolute_updates):
            magnitude_mask = top_fraction_mask(update, self.kappa)
            deviation = (update_magnitude - median_magnitude).abs()
            deviation_mask = top_fraction_mask(deviation, self.kappa)
            critical_mask = magnitude_mask & deviation_mask

            critical_magnitudes = update_magnitude * critical_mask
            agreement = (torch.sign(update) == plausible_sign) & critical_mask
            denominator = critical_magnitudes.sum()
            if denominator.item() <= self.eps:
                score = update.new_tensor(0.0)
            else:
                score = (critical_magnitudes * agreement.to(update.dtype)).sum() / denominator
            scores.append(score)
            retained_coordinates.append(int(critical_mask.sum().item()))

        return torch.stack(scores), retained_coordinates

    def aggregate(self, agent_updates_dict):
        if not agent_updates_dict:
            raise ValueError("FLRobust requires at least one client update.")

        client_ids = list(agent_updates_dict.keys())
        updates = torch.stack([agent_updates_dict[client_id] for client_id in client_ids])
        scores, retained_coordinates = self._magnitude_weighted_sign_alignment(updates)

        median_score = coordinate_median(scores)
        median_offsets = (scores - median_score).abs()
        offset_mean = median_offsets.mean()
        offset_variance = ((median_offsets - offset_mean) ** 2).mean()
        normalized_offsets = (median_offsets - offset_mean) / torch.sqrt(
            offset_variance + self.eps
        )
        retained_mask = normalized_offsets < self.threshold

        fallback_used = False
        if not retained_mask.any():
            retained_mask[torch.argmin(normalized_offsets)] = True
            fallback_used = True

        reputations = []
        for index, client_id in enumerate(client_ids):
            gamma = 1.0 if retained_mask[index].item() else 0.0
            benign_count = self.decay * self.benign_counts.get(client_id, 0.0) + gamma
            malicious_count = (
                self.decay * self.malicious_counts.get(client_id, 0.0) + 1.0 - gamma
            )
            self.benign_counts[client_id] = benign_count
            self.malicious_counts[client_id] = malicious_count
            reputations.append(benign_count / (benign_count + malicious_count))

        reputation_tensor = updates.new_tensor(reputations)
        selected_indices = torch.nonzero(retained_mask, as_tuple=False).flatten()
        selected_weights = reputation_tensor[selected_indices]
        weight_sum = selected_weights.sum()
        if weight_sum.item() <= self.eps:
            selected_weights = torch.ones_like(selected_weights)
            weight_sum = selected_weights.sum()

        aggregated_update = (
            updates[selected_indices] * selected_weights.unsqueeze(1)
        ).sum(dim=0) / weight_sum

        selected_ids = [client_ids[index] for index in selected_indices.tolist()]
        self.last_diagnostics = {
            "client_ids": client_ids,
            "mwsa_scores": scores.detach().cpu().tolist(),
            "median_offsets": median_offsets.detach().cpu().tolist(),
            "normalized_offsets": normalized_offsets.detach().cpu().tolist(),
            "retained_coordinates": retained_coordinates,
            "selected_client_ids": selected_ids,
            "reputations": {
                client_id: reputations[index] for index, client_id in enumerate(client_ids)
            },
            "fallback_used": fallback_used,
        }
        return aggregated_update, self.last_diagnostics
