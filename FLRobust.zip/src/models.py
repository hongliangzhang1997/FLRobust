from resnet import ResNet9
from vgg import VGG
import torchvision.models as tv_models
import torch.nn as nn


def get_model(data, args):
    num_classes = {
        'svhn': 10,
        'cifar10': 10,
        'cifar100': 100,
        'tinyimagenet': 200,
    }.get(data)
    if num_classes is None:
        raise ValueError('Unsupported model dataset: %s' % data)

    model_name = getattr(args, 'model', 'auto')
    if model_name == 'resnet18':
        model = get_resnet18_small(num_classes=num_classes)
    elif model_name == 'resnet9':
        model = ResNet9(3, num_classes=num_classes, args=args)
    elif model_name == 'vgg9':
        model = VGG('VGG9', num_classes=num_classes)
    elif data in ('cifar10', 'svhn'):
        model = ResNet9(3,num_classes=10, args=args)
    elif data == 'cifar100':
        model = VGG('VGG9',num_classes=100)
    elif data == 'tinyimagenet':
        model = get_resnet18_small(num_classes=200)

    return model
         

def get_resnet18_small(num_classes=200):
    """
    Return a ResNet-18 adapted to 32x32 or 64x64 image benchmarks.

    Args:
        num_classes (int): The number of output classes. Default is 200.

    Returns:
        model (torch.nn.Module): Modified ResNet-18 model.
    """
    # Start from an untrained torchvision ResNet-18.
    model = tv_models.resnet18(pretrained=False)

    # Use the small-image stem employed for CIFAR, SVHN, and Tiny-ImageNet.
    model.conv1 = nn.Conv2d(
        in_channels=3, 
        out_channels=64, 
        kernel_size=3, 
        stride=1, 
        padding=1, 
        bias=False
    )
    
    # Adjust the max pooling layer to fit smaller image sizes
    model.maxpool = nn.Identity()

    # Modify the fully connected layer to output num_classes
    model.fc = nn.Linear(model.fc.in_features, num_classes)

    return model


def get_resnet18_64x64(num_classes=200):
    """Backward-compatible alias retained for existing integrations."""
    return get_resnet18_small(num_classes=num_classes)
